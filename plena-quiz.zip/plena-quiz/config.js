const config = {
  leadEndpoint: "",
  whatsappNumber: "5511942664419",   // PROVISÓRIO (número pessoal para testes). Trocar pelo número oficial da PLENA.
};
